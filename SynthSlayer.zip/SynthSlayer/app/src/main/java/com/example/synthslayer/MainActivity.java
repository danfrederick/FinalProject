package com.example.synthslayer;

import android.support.v7.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

}

